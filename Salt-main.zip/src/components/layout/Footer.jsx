import { motion } from "framer-motion";

export default function Footer() {
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      className="border-t border-border/30 py-8 px-6"
    >
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <img
            src="https://media.base44.com/images/public/6a198658e24eed34dca41c95/29b4df462_9c12b16a-854f-4c3b-9d13-5de82e9fc2e1.png"
            alt="Salt"
            className="h-6 w-auto object-contain opacity-60"
          />
          <span className="font-mono text-xs text-muted-foreground tracking-widest">
            SALT EXECUTOR © 2026
          </span>
        </div>
        <div className="flex items-center gap-6">
          <a
            href="https://discord.gg/yZyHEugsPF"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-xs text-muted-foreground hover:text-primary transition-colors tracking-wider"
          >
            DISCORD
          </a>
          <span className="font-mono text-xs text-muted-foreground/40 tracking-wider">
            SYS:ONLINE
          </span>
        </div>
      </div>
    </motion.footer>
  );
}
