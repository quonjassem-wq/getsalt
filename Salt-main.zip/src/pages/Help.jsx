import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import SectionLabel from "@/components/shared/SectionLabel";

export default function Help() {
  return (
    <div className="min-h-screen px-6 pb-32">
      <div className="max-w-5xl mx-auto">
        <section className="py-24 md:py-32">
          <SectionLabel label="Comms Relay" refCode="HLP" />

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl md:text-7xl font-inter font-black tracking-tight text-foreground leading-none mb-8"
          >
            HELP
            <br />
            <span className="text-primary">CENTER</span>
          </motion.h1>
        </section>

        {/* Coming Soon Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="relative backdrop-blur-xl bg-card/40 border border-border/30 rounded-2xl p-12 md:p-20 text-center overflow-hidden"
        >
          {/* Glitch overlay */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className="absolute top-1/4 left-0 right-0 h-px bg-primary/20 glitch-text" />
            <div className="absolute top-2/3 left-0 right-0 h-px bg-primary/10 glitch-text" style={{ animationDelay: "1s" }} />
          </div>

          <motion.div
            animate={{ opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="font-mono text-[10px] tracking-[0.5em] text-primary/60 mb-8"
          >
            [ CLASSIFIED ]
          </motion.div>

          <h2 className="text-4xl md:text-6xl font-inter font-black text-foreground/10 tracking-tight mb-4 select-none">
            COMING SOON
          </h2>

          <p className="font-mono text-sm text-muted-foreground mb-12 max-w-md mx-auto">
            The help center is currently under development. In the meantime, our Discord community is ready to assist you.
          </p>

          <a
            href="https://dsc.gg/getsalt"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button
              size="lg"
              className="bg-primary text-primary-foreground font-mono text-xs tracking-widest px-8 py-6 rounded-full hover:bg-primary/90 glow-pulse group"
            >
              GET HELP ON DISCORD
              <ArrowUpRight className="w-4 h-4 ml-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </Button>
          </a>

          {/* Decorative arrow */}
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="mt-12"
          >
            <ArrowUpRight className="w-12 h-12 text-primary/20 mx-auto rotate-45" />
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
