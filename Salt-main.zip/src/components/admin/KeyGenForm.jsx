import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Copy, Zap } from "lucide-react";
import { toast } from "sonner";

function generateKey() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const seg = () => Array.from({ length: 5 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  return `SALT-${seg()}-${seg()}-${seg()}`;
}

export default function KeyGenForm({ onCreated }) {
  const [hours, setHours] = useState(24);
  const [maxHwids, setMaxHwids] = useState(1);
  const [note, setNote] = useState("");
  const [count, setCount] = useState(1);
  const [loading, setLoading] = useState(false);
  const [lastKeys, setLastKeys] = useState([]);

  const handleGenerate = async (e) => {
    e.preventDefault();
    setLoading(true);
    const created = [];
    for (let i = 0; i < count; i++) {
      const key_value = generateKey();
      const expires_at = new Date(Date.now() + hours * 60 * 60 * 1000).toISOString();
      await base44.entities.Key.create({ key_value, expires_at, max_hwids: maxHwids, note, is_active: true });
      created.push(key_value);
    }
    setLastKeys(created);
    setLoading(false);
    toast.success(`Generated ${count} key(s)`);
    onCreated();
  };

  const copyKey = (k) => {
    navigator.clipboard.writeText(k);
    toast.success("Copied!");
  };

  return (
    <div className="rounded-2xl border border-white/8 bg-white/4 backdrop-blur-sm p-6">
      <div className="flex items-center gap-2 mb-6">
        <Zap className="w-4 h-4 text-primary" />
        <h2 className="font-mono text-xs tracking-widest text-white/80">GENERATE KEYS</h2>
      </div>

      <form onSubmit={handleGenerate} className="space-y-4">
        <div>
          <label className="font-mono text-[10px] tracking-widest text-white/40 block mb-1.5">DURATION (HOURS)</label>
          <Input
            type="number"
            min={1}
            value={hours}
            onChange={e => setHours(Number(e.target.value))}
            className="font-mono text-xs bg-white/5 border-white/10 text-white focus:border-primary/50"
          />
        </div>
        <div>
          <label className="font-mono text-[10px] tracking-widest text-white/40 block mb-1.5">MAX HWIDs</label>
          <Input
            type="number"
            min={1}
            value={maxHwids}
            onChange={e => setMaxHwids(Number(e.target.value))}
            className="font-mono text-xs bg-white/5 border-white/10 text-white focus:border-primary/50"
          />
        </div>
        <div>
          <label className="font-mono text-[10px] tracking-widest text-white/40 block mb-1.5">BATCH COUNT</label>
          <Input
            type="number"
            min={1}
            max={50}
            value={count}
            onChange={e => setCount(Number(e.target.value))}
            className="font-mono text-xs bg-white/5 border-white/10 text-white focus:border-primary/50"
          />
        </div>
        <div>
          <label className="font-mono text-[10px] tracking-widest text-white/40 block mb-1.5">NOTE (OPTIONAL)</label>
          <Input
            type="text"
            value={note}
            onChange={e => setNote(e.target.value)}
            placeholder="e.g. Discord giveaway"
            className="font-mono text-xs bg-white/5 border-white/10 text-white placeholder:text-white/20 focus:border-primary/50"
          />
        </div>
        <Button
          type="submit"
          disabled={loading}
          className="w-full font-mono text-xs tracking-widest rounded-full bg-primary hover:bg-primary/90"
          style={{ boxShadow: "0 0 20px hsl(271 93% 73% / 0.25)" }}
        >
          <Plus className="w-3 h-3 mr-2" />
          {loading ? "GENERATING..." : "GENERATE"}
        </Button>
      </form>

      {lastKeys.length > 0 && (
        <div className="mt-5 space-y-2">
          <p className="font-mono text-[10px] tracking-widest text-white/30">GENERATED:</p>
          {lastKeys.map(k => (
            <div key={k} className="flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-lg px-3 py-2">
              <span className="font-mono text-[10px] text-primary flex-1 truncate">{k}</span>
              <button onClick={() => copyKey(k)} className="text-primary/50 hover:text-primary transition-colors">
                <Copy className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
