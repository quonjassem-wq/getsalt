import { motion } from "framer-motion";

export default function SectionLabel({ label, refCode }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
      className="flex items-center gap-3 mb-8"
    >
      <div className="w-2 h-2 rounded-full bg-primary" />
      <span className="font-mono text-xs tracking-[0.2em] text-primary uppercase">
        {label}
      </span>
      {refCode && (
        <span className="font-mono text-[10px] tracking-widest text-muted-foreground/50 ml-auto">
          REF: {refCode}
        </span>
      )}
    </motion.div>
  );
}
