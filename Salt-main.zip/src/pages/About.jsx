import { motion } from "framer-motion";
import SectionLabel from "@/components/shared/SectionLabel";
import GlassCard from "@/components/shared/GlassCard";
import { Shield, Zap, Users, Infinity } from "lucide-react";

const values = [
  { icon: Infinity, title: "FOREVER FREE", desc: "Salt will always be free to use. We believe everyone deserves access to a powerful executor without a paywall." },
  { icon: Zap, title: "HIGH PERFORMANCE", desc: "Built from the ground up for speed and reliability. Salt executes scripts with minimal latency and maximum stability." },
  { icon: Shield, title: "ACTIVE SECURITY", desc: "Our team works around the clock to maintain undetected status and bypass client modification bans." },
  { icon: Users, title: "COMMUNITY DRIVEN", desc: "Salt is shaped by its community. Join our Discord to share feedback, report issues, and request features." },
];

export default function About() {
  return (
    <div className="min-h-screen px-6 pb-32">
      <div className="max-w-5xl mx-auto">
        {/* Hero */}
        <section className="py-24 md:py-32 relative">
          <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />
          
          <SectionLabel label="About Salt" refCode="001" />
          
          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl md:text-7xl font-inter font-black tracking-tight text-foreground leading-none mb-8"
          >
            THE NEXT
            <br />
            <span className="text-primary">GENERATION</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="font-inter text-lg text-muted-foreground max-w-2xl leading-relaxed"
          >
            Salt is a next-generation executor designed for power, speed, and accessibility. 
            Built by a dedicated team, Salt delivers a premium execution experience — completely free. 
            With active bypass development, multi-instance support, and a thriving community, 
            Salt is redefining what a free executor can be.
          </motion.p>
        </section>

        {/* Values Grid */}
        <section>
          <SectionLabel label="Core Values" refCode="002" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {values.map((val, i) => (
              <GlassCard key={val.title} delay={i * 0.1} className="p-8 group hover:border-primary/30 transition-all duration-500">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-primary/10 border border-primary/20 group-hover:bg-primary/20 transition-colors">
                    <val.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-mono text-xs tracking-widest text-foreground mb-2">{val.title}</h3>
                    <p className="font-inter text-sm text-muted-foreground leading-relaxed">{val.desc}</p>
                  </div>
                </div>
              </GlassCard>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
