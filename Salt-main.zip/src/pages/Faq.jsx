import SectionLabel from "@/components/shared/SectionLabel";
import FaqItem from "@/components/faq/FaqItem";
import PricingTable from "@/components/faq/PricingTable";
import { motion } from "framer-motion";

const faqData = [
  { q: "Is Salt Paid?", a: "Salt is gonna be forever free with ads. We believe in keeping powerful tools accessible to everyone.", ref: "001" },
  { q: "Is Salt Keyless?", a: "No, Salt has a keysystem. You'll need to obtain a key to use the executor.", ref: "002" },
  { q: "When will Salt Release?", a: "Salt hasn't released yet. Stay tuned and keep an eye on our Discord for the official release announcement.", ref: "003" },
  { q: "Does Salt support Multi Instance?", a: "Currently, it is working well since our last test. Multi instance support lets you run multiple sessions simultaneously.", ref: "004" },
  { q: "Is Salt undetected?", a: "Salt Team are trying their best to bypass client modification bans, but just in case use an alt — there is a risk in ban waves.", ref: "005" },
];

export default function Faq() {
  return (
    <div className="min-h-screen px-6 pb-32">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <section className="py-24 md:py-32 relative">
          <div className="absolute top-20 left-0 w-[300px] h-[300px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />

          <SectionLabel label="Data Ledger" refCode="FAQ" />

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl md:text-7xl font-inter font-black tracking-tight text-foreground leading-none mb-4"
          >
            FREQ<span className="text-primary">UENTLY</span>
            <br />
            ASKED
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="font-mono text-xs tracking-widest text-muted-foreground mt-4"
          >
            KNOWLEDGE BASE // CLICK TO EXPAND
          </motion.p>
        </section>

        {/* Pricing */}
        <section className="mb-20">
          <SectionLabel label="Key Pricing" refCode="PRC" />
          <PricingTable />
        </section>

        {/* FAQ Items */}
        <section>
          <SectionLabel label="Questions" refCode="QST" />
          <div className="space-y-3">
            {faqData.map((item, i) => (
              <FaqItem
                key={item.ref}
                question={item.q}
                answer={item.a}
                refCode={item.ref}
                index={i}
              />
            ))}
          </div>

          {/* More in Discord */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="mt-8 text-center"
          >
            <a
              href="https://discord.gg/yZyHEugsPF"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 font-mono text-xs tracking-widest text-muted-foreground hover:text-primary transition-colors"
            >
              <span className="w-8 h-px bg-border" />
              MORE QUESTIONS? JOIN DISCORD
              <span className="w-8 h-px bg-border" />
            </a>
          </motion.div>
        </section>
      </div>
    </div>
  );
}
