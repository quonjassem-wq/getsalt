import { motion, AnimatePresence } from "framer-motion";
import { Download, ArrowUpRight, Shield, Zap, Cpu } from "lucide-react";
import { Button } from "@/components/ui/button";
import GlassCard from "@/components/shared/GlassCard";
import { useState } from "react";

const features = [
  { icon: Zap, label: "FAST EXECUTION", desc: "Lightning-speed script injection" },
  { icon: Shield, label: "SECURE", desc: "Actively bypassing detection" },
  { icon: Cpu, label: "MULTI INSTANCE", desc: "Run multiple sessions" },
];

export default function Home() {
  const [showComingSoon, setShowComingSoon] = useState(false);

  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex flex-col items-center justify-center px-6">
        {/* Violet glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[150px] pointer-events-none" />
        
        {/* Logo */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="relative z-10 mb-10 animate-float"
        >
          <img
            src="https://media.base44.com/images/public/6a198658e24eed34dca41c95/29b4df462_9c12b16a-854f-4c3b-9d13-5de82e9fc2e1.png"
            alt="Salt"
            className="h-28 md:h-40 w-auto object-contain drop-shadow-[0_0_60px_rgba(255,255,255,0.08)]"
          />
        </motion.div>

        {/* Coming Soon + Tagline */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="text-center z-10"
        >
          <motion.div
            initial={{ opacity: 0, letterSpacing: "0.5em" }}
            animate={{ opacity: 1, letterSpacing: "0.4em" }}
            transition={{ delay: 0.5, duration: 1 }}
            className="font-mono text-[10px] tracking-[0.4em] text-primary/70 mb-3 uppercase"
          >
            Next Generation Executor
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            className="relative inline-block"
          >
            <span className="text-4xl md:text-6xl font-inter font-black tracking-[0.15em] text-foreground/90 uppercase">
              COMING SOON
            </span>
            <motion.div
              className="absolute -bottom-1 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent"
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 2.5, repeat: Infinity, repeatType: "mirror" }}
            />
          </motion.div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="flex flex-col sm:flex-row items-center gap-4 mt-12 z-10"
        >
          <div className="relative">
            <Button
              size="lg"
              onClick={() => setShowComingSoon(true)}
              className="relative group bg-primary text-primary-foreground font-mono text-xs tracking-widest px-8 py-6 rounded-full hover:bg-primary/90 transition-all duration-300 glow-pulse"
            >
              <Download className="w-4 h-4 mr-3" />
              DOWNLOAD SALT
              <div className="absolute inset-0 rounded-full bg-primary/20 opacity-0 group-hover:opacity-100 group-hover:scale-110 transition-all duration-500" />
            </Button>
            <AnimatePresence>
              {showComingSoon && (
                <motion.div
                  initial={{ opacity: 0, y: 8, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className="absolute top-full mt-3 left-1/2 -translate-x-1/2 z-50 w-64 backdrop-blur-xl bg-card/80 border border-primary/30 rounded-xl p-4 text-center shadow-xl"
                >
                  <p className="font-mono text-xs tracking-widest text-primary mb-3">COMING SOON</p>
                  <a
                    href="https://discord.gg/yZyHEugsPF"
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => setShowComingSoon(false)}
                    className="font-mono text-[10px] tracking-widest text-muted-foreground hover:text-primary transition-colors underline underline-offset-4"
                  >
                    JOIN DISCORD FOR UPDATES
                  </a>
                  <button
                    onClick={() => setShowComingSoon(false)}
                    className="absolute top-2 right-3 text-muted-foreground hover:text-foreground text-xs"
                  >✕</button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <a
            href="https://discord.gg/yZyHEugsPF"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button
              size="lg"
              variant="outline"
              className="font-mono text-xs tracking-widest px-8 py-6 rounded-full border-border/50 hover:border-primary/50 hover:text-primary transition-all duration-300 group"
            >
              JOIN SALT
              <ArrowUpRight className="w-4 h-4 ml-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </Button>
          </a>
        </motion.div>

        {/* Status bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="flex flex-wrap items-center justify-center gap-4 md:gap-6 mt-16 z-10"
        >
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-yellow-400 animate-pulse" />
            <span className="font-mono text-[10px] tracking-widest text-yellow-400">STATUS: ALMOST RELEASED</span>
          </div>
          <div className="w-px h-3 bg-border hidden md:block" />
          <span className="font-mono text-[10px] tracking-widest text-muted-foreground">V0.0.1</span>
          <div className="w-px h-3 bg-border hidden md:block" />
          <span className="font-mono text-[10px] tracking-widest text-muted-foreground">FREE</span>
          <div className="w-px h-3 bg-border hidden md:block" />
          <div className="flex items-center gap-3">
            <span className="font-mono text-[10px] tracking-widest text-foreground/80">UNC <span className="text-primary font-bold">100%</span></span>
            <span className="w-px h-3 bg-border/50" />
            <span className="font-mono text-[10px] tracking-widest text-foreground/80">sUNC <span className="text-primary/70 font-bold">98%</span></span>
          </div>
        </motion.div>
      </section>

      {/* Features */}
      <section className="px-6 pb-32 pt-16">
        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-4">
          {features.map((feat, i) => (
            <GlassCard key={feat.label} delay={i * 0.15} className="p-8 group hover:border-primary/30 transition-all duration-500">
              <feat.icon className="w-6 h-6 text-primary mb-4 group-hover:scale-110 transition-transform" />
              <h3 className="font-mono text-xs tracking-widest text-foreground mb-2">{feat.label}</h3>
              <p className="font-inter text-sm text-muted-foreground">{feat.desc}</p>
            </GlassCard>
          ))}
        </div>
      </section>
    </div>
  );
}
