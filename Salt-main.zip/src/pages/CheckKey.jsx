import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CheckCircle2, XCircle, Loader2, Key, Clock } from "lucide-react";
import { isPast, formatDistanceToNow } from "date-fns";
import SectionLabel from "@/components/shared/SectionLabel";

export default function CheckKey() {
  const [keyInput, setKeyInput] = useState("");
  const [status, setStatus] = useState(null); // null | 'valid' | 'expired' | 'disabled' | 'notfound'
  const [expiresAt, setExpiresAt] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleCheck = async (e) => {
    e.preventDefault();
    if (!keyInput.trim()) return;
    setLoading(true);
    setStatus(null);

    const results = await base44.entities.Key.filter({ key_value: keyInput.trim() });

    if (!results || results.length === 0) {
      setStatus("notfound");
      setLoading(false);
      return;
    }

    const key = results[0];
    setExpiresAt(key.expires_at);

    if (!key.is_active) {
      setStatus("disabled");
    } else if (isPast(new Date(key.expires_at))) {
      setStatus("expired");
    } else {
      setStatus("valid");
    }

    setLoading(false);
  };

  const statusConfig = {
    valid: {
      icon: CheckCircle2,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10 border-emerald-500/20",
      title: "Key is Valid",
      desc: expiresAt ? `Expires ${formatDistanceToNow(new Date(expiresAt), { addSuffix: true })}` : "",
    },
    expired: {
      icon: Clock,
      color: "text-amber-400",
      bg: "bg-amber-500/10 border-amber-500/20",
      title: "Key Expired",
      desc: expiresAt ? `Expired ${formatDistanceToNow(new Date(expiresAt), { addSuffix: true })}` : "",
    },
    disabled: {
      icon: XCircle,
      color: "text-red-400",
      bg: "bg-red-500/10 border-red-500/20",
      title: "Key Disabled",
      desc: "This key has been deactivated by an admin.",
    },
    notfound: {
      icon: XCircle,
      color: "text-red-400",
      bg: "bg-red-500/10 border-red-500/20",
      title: "Key Not Found",
      desc: "No key matching that value exists.",
    },
  };

  const current = status ? statusConfig[status] : null;

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center px-6 py-20">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/6 rounded-full blur-[140px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-lg">
        <SectionLabel label="Key Checker" refCode="SALT-CHK-01" />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <h1 className="font-inter font-black text-3xl md:text-4xl tracking-tight text-foreground mb-2">
            Check Your <span className="text-primary">Key</span>
          </h1>
          <p className="font-mono text-xs tracking-widest text-muted-foreground mb-10">
            Enter your key below to verify its status.
          </p>

          <form onSubmit={handleCheck} className="flex gap-3 mb-6">
            <div className="relative flex-1">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={keyInput}
                onChange={e => { setKeyInput(e.target.value); setStatus(null); }}
                placeholder="SALT-XXXXX-XXXXX-XXXXX"
                className="pl-10 font-mono text-xs tracking-wider bg-background border-border"
              />
            </div>
            <Button
              type="submit"
              disabled={loading || !keyInput.trim()}
              className="font-mono text-xs tracking-widest rounded-full px-6 bg-primary hover:bg-primary/90"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "CHECK"}
            </Button>
          </form>

          <AnimatePresence mode="wait">
            {current && (
              <motion.div
                key={status}
                initial={{ opacity: 0, y: 16, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -10, scale: 0.97 }}
                transition={{ duration: 0.4 }}
                className={`flex items-start gap-4 rounded-2xl border p-5 ${current.bg}`}
              >
                <current.icon className={`w-6 h-6 mt-0.5 shrink-0 ${current.color}`} />
                <div>
                  <p className={`font-inter font-bold text-base ${current.color}`}>{current.title}</p>
                  <p className="font-mono text-[11px] tracking-wide text-muted-foreground mt-1">{current.desc}</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
}
