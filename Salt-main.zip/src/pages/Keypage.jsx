import { motion } from "framer-motion";
import { ExternalLink, Key } from "lucide-react";
import { Button } from "@/components/ui/button";
import GlassCard from "@/components/shared/GlassCard";
import SectionLabel from "@/components/shared/SectionLabel";

export default function KeyPage() {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center px-6 py-20">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/8 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative z-10 w-full max-w-xl">
        <SectionLabel label="Key System" refCode="SALT-KEY-01" />

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="font-inter font-black text-3xl md:text-4xl tracking-tight text-foreground mb-3">
            Get Your <span className="text-primary">Access Key</span>
          </h1>
          <p className="font-mono text-xs tracking-widest text-muted-foreground mb-10">
            Complete an offer below to receive your 24-hour key. Keys are locked to your device.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
            <GlassCard className="p-6 hover:border-primary/30 transition-all duration-300 group">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <ExternalLink className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-mono text-xs tracking-widest text-foreground mb-1">LINKVERTISE</h3>
                  <p className="font-inter text-xs text-muted-foreground">Fast & simple — complete a short ad</p>
                </div>
                <a
                  href="https://linkvertise.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full"
                >
                  <Button className="w-full font-mono text-xs tracking-widest rounded-full bg-primary hover:bg-primary/90">
                    GET KEY
                  </Button>
                </a>
              </div>
            </GlassCard>

            <GlassCard className="p-6 hover:border-primary/30 transition-all duration-300 group">
              <div className="flex flex-col items-center text-center gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Key className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-mono text-xs tracking-widest text-foreground mb-1">LOOTLABS</h3>
                  <p className="font-inter text-xs text-muted-foreground">More offers, more options</p>
                </div>
                <a
                  href="https://lootlabs.gg"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full"
                >
                  <Button className="w-full font-mono text-xs tracking-widest rounded-full bg-primary hover:bg-primary/90">
                    GET KEY
                  </Button>
                </a>
              </div>
            </GlassCard>
          </div>

          <GlassCard className="p-6">
            <p className="font-mono text-[10px] tracking-widest text-muted-foreground text-center leading-relaxed">
              AFTER COMPLETING THE OFFER, YOU WILL RECEIVE YOUR KEY.<br />
              ENTER IT IN THE SALT EXECUTOR TO UNLOCK ACCESS.<br />
              KEYS LAST 24 HOURS AND ARE LOCKED TO YOUR DEVICE.
            </p>
          </GlassCard>
        </motion.div>
      </div>
    </div>
  );
}
