import { motion } from "framer-motion";
import SectionLabel from "@/components/shared/SectionLabel";
import GlassCard from "@/components/shared/GlassCard";
import { Crown, Star } from "lucide-react";

const team = [
{ name: "SALT", role: "OWNER", icon: Crown, desc: "Founder and lead developer of the Salt project. Responsible for core architecture and vision." },
{ name: "SUGAR", role: "CO-OWNER", icon: Star, desc: "Co-founder and key contributor. Helps drive development, community management, and strategic direction." }];


export default function Credits() {
  return (
    <div className="min-h-screen px-6 pb-32">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <section className="py-24 md:py-32 relative">
          <div className="absolute top-20 right-0 w-[400px] h-[400px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />

          <SectionLabel label="Genesis File" refCode="CRD" />

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl md:text-7xl font-inter font-black tracking-tight text-foreground leading-none mb-4">
            
            THE
            <br />
            <span className="text-primary">TEAM</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="font-mono text-xs tracking-widest text-muted-foreground mt-4">
            
            THE PEOPLE BEHIND SALT
          </motion.p>
        </section>

        {/* Marquee */}
        <div className="overflow-hidden mb-20 border-y border-border/20 py-8">
          <motion.div
            className="flex whitespace-nowrap animate-marquee"
            style={{ width: "fit-content" }}>
            
            {[...Array(6)].map((_, i) =>
            <span key={i} className="text-6xl md:text-8xl font-inter font-black tracking-tight text-foreground/[0.03] mx-8 select-none">
                SALT • SUGAR • SALT • SUGAR •
              </span>
            )}
          </motion.div>
        </div>

        {/* Team Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {team.map((member, i) =>
          <GlassCard
            key={member.name}
            delay={i * 0.2}
            className="p-8 md:p-10 group hover:border-primary/30 transition-all duration-500 relative overflow-hidden">
            
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-[60px] pointer-events-none group-hover:bg-primary/10 transition-colors" />

              <div className="flex items-center gap-4 mb-6">
                <div className="w-14 h-14 rounded-2xl border border-primary/20 flex items-center justify-center group-hover:bg-primary/20 transition-colors bg-gray-500/10">
                  <member.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-inter font-black text-2xl text-foreground tracking-tight">
                    ~ {member.name}
                  </h3>
                  <span className="font-mono text-[10px] tracking-[0.3em] text-primary">
                    {member.role}
                  </span>
                </div>
              </div>

              <p className="font-inter text-sm text-muted-foreground leading-relaxed">
                {member.desc}
              </p>

              <div className="mt-6 pt-6 border-t border-border/20">
                <span className="font-mono text-[10px] tracking-widest text-muted-foreground/40">
                  MEMBER #{String(i + 1).padStart(3, "0")}
                </span>
              </div>
            </GlassCard>
          )}
        </div>

        {/* Join CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mt-20 text-center">
          
          <p className="font-mono text-xs text-muted-foreground tracking-widest mb-4">
            WANT TO CONTRIBUTE?
          </p>
          <a
            href="https://discord.gg/yZyHEugsPF"
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono text-sm text-primary hover:text-primary/80 tracking-widest transition-colors underline underline-offset-4 decoration-primary/30">
            
            JOIN OUR DISCORD →
          </a>
        </motion.div>
      </div>
    </div>);

}
