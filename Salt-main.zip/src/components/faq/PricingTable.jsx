import { motion } from "framer-motion";
import { Infinity, Clock, Calendar, CalendarDays } from "lucide-react";
import GlassCard from "@/components/shared/GlassCard";

const plans = [
  { duration: "1 DAY", price: "ADS", desc: "Free with advertisements", icon: Clock, highlight: false },
  { duration: "1 WEEK", price: "$2.99", desc: "7 days ad-free access", icon: Calendar, highlight: false },
  { duration: "30 DAYS", price: "$9.99", desc: "Full month of access", icon: CalendarDays, highlight: false },
  { duration: "PERMANENT", price: "$14.99", desc: "Lifetime access key", icon: Infinity, highlight: true },
];

export default function PricingTable() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {plans.map((plan, i) => (
        <GlassCard
          key={plan.duration}
          delay={i * 0.1}
          className={`p-6 text-center relative overflow-hidden group transition-all duration-500 ${
            plan.highlight ? "border-primary/40 glow-pulse" : "hover:border-primary/20"
          }`}
        >
          {plan.highlight && (
            <motion.div
              className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 2, repeat: Infinity, repeatType: "mirror" }}
            />
          )}
          <plan.icon className={`w-6 h-6 mx-auto mb-4 ${plan.highlight ? "text-primary" : "text-muted-foreground"}`} />
          <span className="font-mono text-[10px] tracking-widest text-muted-foreground block mb-3">
            {plan.duration}
          </span>
          <span className={`font-inter font-black text-2xl block mb-2 ${
            plan.highlight ? "text-primary" : "text-foreground"
          }`}>
            {plan.price}
          </span>
          <span className="font-inter text-xs text-muted-foreground">{plan.desc}</span>
        </GlassCard>
      ))}
    </div>
  );
}
