import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RefreshCw, Lock, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import KeyTable from "@/components/admin/KeyTable";
import KeyGenForm from "@/components/admin/KeyGenForm";

const ADMIN_PASSWORD = "SALTY-WAS-HEREWITHSUGAR_ezez.meow.ez.kidd_keno";

export default function AdminGen() {
  const [authed, setAuthed] = useState(false);
  const [pwInput, setPwInput] = useState("");
  const [pwError, setPwError] = useState(false);
  const [refreshTick, setRefreshTick] = useState(0);

  const handleLogin = (e) => {
    e.preventDefault();
    if (pwInput === ADMIN_PASSWORD) {
      setAuthed(true);
      setPwError(false);
    } else {
      setPwError(true);
    }
  };

  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6"
        style={{ background: "linear-gradient(135deg, #0a0a0a 0%, #12062a 50%, #0a0a0a 100%)" }}
      >
        <div className="w-full max-w-sm">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl p-8 shadow-2xl">
              <div className="flex flex-col items-center gap-3 mb-8">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <Lock className="w-5 h-5 text-primary" />
                </div>
                <h1 className="font-inter font-bold text-lg text-white">Admin Access</h1>
                <p className="font-mono text-[10px] tracking-widest text-white/40">SALT KEY MANAGER</p>
              </div>
              <form onSubmit={handleLogin} className="space-y-4">
                <Input
                  type="password"
                  placeholder="Enter admin password"
                  value={pwInput}
                  onChange={(e) => { setPwInput(e.target.value); setPwError(false); }}
                  className="font-mono text-xs bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-primary/60"
                />
                {pwError && (
                  <p className="font-mono text-[10px] tracking-widest text-red-400 text-center">INVALID PASSWORD</p>
                )}
                <Button type="submit" className="w-full font-mono text-xs tracking-widest rounded-full bg-primary hover:bg-primary/90">
                  UNLOCK
                </Button>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen"
      style={{ background: "linear-gradient(160deg, #0d0d0d 0%, #130826 40%, #0d0d0d 100%)" }}
    >
      {/* Top gradient bar */}
      <div className="h-1 w-full" style={{ background: "linear-gradient(90deg, transparent, hsl(271 93% 73%), transparent)" }} />

      <div className="px-6 py-12 max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center justify-between mb-10"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h1 className="font-inter font-black text-xl text-white">Key Manager</h1>
              <p className="font-mono text-[10px] tracking-widest text-white/30">SALT ADMIN PANEL</p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setRefreshTick(t => t + 1)}
            className="font-mono text-xs tracking-widest border-white/10 bg-white/5 text-white/60 hover:bg-white/10 hover:text-white hover:border-primary/40 rounded-full"
          >
            <RefreshCw className="w-3 h-3 mr-2" />
            REFRESH
          </Button>
        </motion.div>

        {/* Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <KeyGenForm onCreated={() => setRefreshTick(t => t + 1)} />
          </div>
          <div className="lg:col-span-2">
            <KeyTable refreshTick={refreshTick} onDeleted={() => setRefreshTick(t => t + 1)} />
          </div>
        </div>
      </div>
    </div>
  );
}
