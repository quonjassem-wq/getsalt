import { useState, useEffect } from "react";

export default function TypewriterText({ text, speed = 20, onComplete, isActive = true }) {
  const [displayed, setDisplayed] = useState("");
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!isActive) {
      setDisplayed("");
      setDone(false);
      return;
    }
    setDisplayed("");
    setDone(false);
    let i = 0;
    const interval = setInterval(() => {
      if (i < text.length) {
        setDisplayed(text.slice(0, i + 1));
        i++;
      } else {
        setDone(true);
        clearInterval(interval);
        onComplete?.();
      }
    }, speed);
    return () => clearInterval(interval);
  }, [text, isActive]);

  return (
    <span className="font-mono text-sm text-muted-foreground leading-relaxed">
      {displayed}
      {!done && isActive && <span className="text-primary animate-pulse">▋</span>}
    </span>
  );
}
