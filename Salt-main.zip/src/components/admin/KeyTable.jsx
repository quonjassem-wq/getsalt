import { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Trash2, Copy, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { format, isPast } from "date-fns";

export default function KeyTable({ refreshTick, onDeleted }) {
  const [keys, setKeys] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    base44.entities.Key.list("-created_date", 100).then(data => {
      setKeys(data);
      setLoading(false);
    });
  }, [refreshTick]);

  const deleteKey = async (id) => {
    await base44.entities.Key.delete(id);
    toast.success("Key deleted");
    onDeleted();
  };

  const copyKey = (k) => {
    navigator.clipboard.writeText(k);
    toast.success("Copied!");
  };

  const toggleActive = async (key) => {
    await base44.entities.Key.update(key.id, { is_active: !key.is_active });
    toast.success(key.is_active ? "Key deactivated" : "Key activated");
    onDeleted();
  };

  return (
    <div className="rounded-2xl border border-white/8 bg-white/4 backdrop-blur-sm p-6">
      <div className="flex items-center gap-2 mb-6">
        <KeyRound className="w-4 h-4 text-primary" />
        <h2 className="font-mono text-xs tracking-widest text-white/80">ALL KEYS</h2>
        <span className="ml-auto font-mono text-[10px] text-white/30 bg-white/5 px-2 py-0.5 rounded-full">{keys.length}</span>
      </div>

      {loading ? (
        <p className="font-mono text-[10px] text-white/30 py-4 text-center">LOADING...</p>
      ) : keys.length === 0 ? (
        <p className="font-mono text-[10px] text-white/30 py-4 text-center">NO KEYS FOUND</p>
      ) : (
        <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
          {keys.map(key => {
            const expired = isPast(new Date(key.expires_at));
            const inactive = !key.is_active;
            return (
              <div
                key={key.id}
                className={`flex flex-wrap items-center gap-2 rounded-xl px-4 py-3 border transition-all ${
                  expired || inactive
                    ? "border-white/5 bg-white/2 opacity-50"
                    : "border-white/8 bg-white/5 hover:bg-white/8"
                }`}
              >
                <span className="font-mono text-[10px] text-primary flex-1 min-w-0 truncate">{key.key_value}</span>

                <div className="flex items-center gap-3 shrink-0 flex-wrap">
                  {/* Status badge */}
                  <span className={`font-mono text-[9px] tracking-widest px-2 py-0.5 rounded-full border ${
                    expired
                      ? "bg-red-500/10 border-red-500/20 text-red-400"
                      : inactive
                      ? "bg-white/5 border-white/10 text-white/30"
                      : "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                  }`}>
                    {expired ? "EXPIRED" : inactive ? "OFF" : "ACTIVE"}
                  </span>

                  {/* Expiry */}
                  <span className="font-mono text-[9px] text-white/30 hidden sm:block">
                    {format(new Date(key.expires_at), "MM/dd HH:mm")}
                  </span>

                  {/* HWID */}
                  <span className="font-mono text-[9px] text-white/30 hidden md:block">
                    {key.hwid ? key.hwid.slice(0, 8) + "…" : "NO HWID"}
                  </span>

                  {/* Actions */}
                  <button onClick={() => copyKey(key.key_value)} className="text-white/30 hover:text-primary transition-colors" title="Copy">
                    <Copy className="w-3 h-3" />
                  </button>
                  <button
                    onClick={() => toggleActive(key)}
                    className="font-mono text-[9px] text-white/30 hover:text-primary transition-colors"
                  >
                    {key.is_active ? "DISABLE" : "ENABLE"}
                  </button>
                  <button onClick={() => deleteKey(key.id)} className="text-white/20 hover:text-red-400 transition-colors" title="Delete">
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
